// script.js
function openModal(content) {
    document.getElementById('myModal').style.display = 'block';
    document.getElementById('modalText').innerText = content;
}

function closeModal() {
    document.getElementById('myModal').style.display = 'none';
}

// Close the modal when clicking outside of the modal content
window.onclick = function(event) {
    if (event.target == document.getElementById('myModal')) {
        document.getElementById('myModal').style.display = 'none';
    }
}
const modalContentArray = [
    {
      title: 'C++',
      description: 'Basic of C++',
      videoUrl: 'https://youtu.be/ESnrn1kAD4E'
    },
    {
      title: 'Variables',
      description: 'Learn about variables in C++.',
      videoUrl: ''
    },
    {
      title: 'Objects',
      description: 'Understanding objects in C++.',
      videoUrl: ''
    },
    {
      title: 'Function',
      description: 'Functions in C++.',
      videoUrl: ''
    },
    {
      title: 'Files Input / Output',
      description: 'Handling files in C++.',
      videoUrl: ''
    }
  ];
  
  function openModal(index) {
    const content = modalContentArray[index];
    let modalBodyContent = `<h2>${content.title}</h2><p>${content.description}</p>`;
    
    // Add video if URL is present
    if (content.videoUrl) {
      modalBodyContent += `<iframe width="100%" height="315" src="${content.videoUrl}?autoplay=1" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>`;
    }
  
    // Set the content into the modal body
    document.getElementById('modal-body').innerHTML = modalBodyContent;
  
    // Show the modal
    document.getElementById('myModal').style.display = 'block';
  }
  
  function closeModal() {
    // Hide the modal
    document.getElementById('myModal').style.display = 'none';
  
    // Optionally, stop the video when closing the modal
    document.getElementById('modal-body').innerHTML = '';
  }
  
  // Close the modal if the user clicks outside of it
  window.onclick = function(event) {
    var modal = document.getElementById('myModal');
    if (event.target === modal) {
      closeModal();
    }
  }